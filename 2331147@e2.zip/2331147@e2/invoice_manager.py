import sqlite3
import pandas as pd
from datetime import datetime, timedelta
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import json
import uuid

class InvoiceManager:
    """
    Comprehensive invoice management system with automated reminders
    """
    
    def __init__(self, db_path='finance_data.db'):
        self.db_path = db_path
        self.init_invoice_tables()
    
    def init_invoice_tables(self):
        """Initialize invoice-related database tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Invoices table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_number TEXT UNIQUE NOT NULL,
                client_name TEXT NOT NULL,
                client_email TEXT NOT NULL,
                amount REAL NOT NULL,
                issue_date TEXT NOT NULL,
                due_date TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                description TEXT,
                payment_terms INTEGER DEFAULT 30,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Invoice items table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS invoice_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_id INTEGER,
                description TEXT NOT NULL,
                quantity REAL NOT NULL,
                unit_price REAL NOT NULL,
                total REAL NOT NULL,
                FOREIGN KEY (invoice_id) REFERENCES invoices (id)
            )
        ''')
        
        # Payment reminders table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payment_reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_id INTEGER,
                reminder_date TEXT NOT NULL,
                reminder_type TEXT NOT NULL,
                sent BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (invoice_id) REFERENCES invoices (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_invoice(self, client_name, client_email, items, payment_terms=30, description=""):
        """
        Create a new invoice
        
        Args:
            client_name (str): Client's name
            client_email (str): Client's email
            items (list): List of items [{'description': str, 'quantity': float, 'unit_price': float}]
            payment_terms (int): Payment terms in days
            description (str): Invoice description
        
        Returns:
            str: Invoice number
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Generate unique invoice number
            invoice_number = f"INV-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
            
            # Calculate total amount
            total_amount = sum(item['quantity'] * item['unit_price'] for item in items)
            
            # Set dates
            issue_date = datetime.now().strftime('%Y-%m-%d')
            due_date = (datetime.now() + timedelta(days=payment_terms)).strftime('%Y-%m-%d')
            
            # Insert invoice
            cursor.execute('''
                INSERT INTO invoices (invoice_number, client_name, client_email, amount, 
                                    issue_date, due_date, description, payment_terms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (invoice_number, client_name, client_email, total_amount, 
                  issue_date, due_date, description, payment_terms))
            
            invoice_id = cursor.lastrowid
            
            # Insert invoice items
            for item in items:
                total_item_price = item['quantity'] * item['unit_price']
                cursor.execute('''
                    INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, total)
                    VALUES (?, ?, ?, ?, ?)
                ''', (invoice_id, item['description'], item['quantity'], item['unit_price'], total_item_price))
            
            # Schedule payment reminders
            self.schedule_payment_reminders(invoice_id, due_date)
            
            conn.commit()
            conn.close()
            
            return invoice_number
            
        except Exception as e:
            print(f"Error creating invoice: {e}")
            return None
    
    def schedule_payment_reminders(self, invoice_id, due_date):
        """Schedule automated payment reminders"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            due_date_obj = datetime.strptime(due_date, '%Y-%m-%d')
            
            # Schedule reminders
            reminders = [
                (due_date_obj - timedelta(days=7), "7_days_before"),
                (due_date_obj - timedelta(days=3), "3_days_before"),
                (due_date_obj, "due_date"),
                (due_date_obj + timedelta(days=7), "7_days_overdue"),
                (due_date_obj + timedelta(days=30), "30_days_overdue")
            ]
            
            for reminder_date, reminder_type in reminders:
                if reminder_date >= datetime.now():
                    cursor.execute('''
                        INSERT INTO payment_reminders (invoice_id, reminder_date, reminder_type)
                        VALUES (?, ?, ?)
                    ''', (invoice_id, reminder_date.strftime('%Y-%m-%d'), reminder_type))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            print(f"Error scheduling reminders: {e}")
    
    def get_pending_invoices(self):
        """Get all pending invoices"""
        conn = sqlite3.connect(self.db_path)
        
        query = '''
            SELECT i.*, 
                   CASE 
                       WHEN date(i.due_date) < date('now') THEN 'overdue'
                       WHEN date(i.due_date) = date('now') THEN 'due_today'
                       ELSE 'pending'
                   END as payment_status
            FROM invoices i
            WHERE i.status = 'pending'
            ORDER BY i.due_date
        '''
        
        invoices_df = pd.read_sql_query(query, conn)
        conn.close()
        
        return invoices_df
    
    def get_overdue_invoices(self):
        """Get all overdue invoices"""
        conn = sqlite3.connect(self.db_path)
        
        query = '''
            SELECT * FROM invoices 
            WHERE status = 'pending' AND date(due_date) < date('now')
            ORDER BY due_date
        '''
        
        overdue_df = pd.read_sql_query(query, conn)
        conn.close()
        
        return overdue_df
    
    def mark_invoice_paid(self, invoice_number, payment_date=None):
        """Mark an invoice as paid"""
        if payment_date is None:
            payment_date = datetime.now().strftime('%Y-%m-%d')
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE invoices 
                SET status = 'paid' 
                WHERE invoice_number = ?
            ''', (invoice_number,))
            
            # Add payment transaction
            cursor.execute('''
                SELECT amount, client_name FROM invoices WHERE invoice_number = ?
            ''', (invoice_number,))
            
            result = cursor.fetchone()
            if result:
                amount, client_name = result
                
                # Add to transactions table
                cursor.execute('''
                    INSERT INTO transactions (date, description, category, amount, revenue_stream)
                    VALUES (?, ?, ?, ?, ?)
                ''', (payment_date, f"Payment from {client_name} - {invoice_number}", 
                      "Revenue", amount, "Invoice Payments"))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            print(f"Error marking invoice as paid: {e}")
            return False
    
    def send_payment_reminder(self, invoice_id, smtp_config):
        """
        Send payment reminder email
        
        Args:
            invoice_id (int): Invoice ID
            smtp_config (dict): SMTP configuration
        """
        try:
            conn = sqlite3.connect(self.db_path)
            
            # Get invoice details
            invoice_query = '''
                SELECT invoice_number, client_name, client_email, amount, due_date, description
                FROM invoices WHERE id = ?
            '''
            
            invoice_data = pd.read_sql_query(invoice_query, conn, params=(invoice_id,))
            
            if invoice_data.empty:
                return False
            
            invoice = invoice_data.iloc[0]
            
            # Create email
            msg = MIMEMultipart()
            msg['From'] = smtp_config['email']
            msg['To'] = invoice['client_email']
            msg['Subject'] = f"Payment Reminder - Invoice {invoice['invoice_number']}"
            
            # Email body
            body = f"""
            Dear {invoice['client_name']},
            
            This is a friendly reminder that payment for Invoice {invoice['invoice_number']} 
            is due on {invoice['due_date']}.
            
            Invoice Details:
            - Amount: ${invoice['amount']:,.2f}
            - Due Date: {invoice['due_date']}
            - Description: {invoice['description']}
            
            Please process your payment at your earliest convenience.
            
            If you have already made this payment, please disregard this reminder.
            
            Thank you for your business!
            
            Best regards,
            Your Finance Team
            """
            
            msg.attach(MIMEText(body, 'plain'))
            
            # Send email
            server = smtplib.SMTP(smtp_config['server'], smtp_config['port'])
            server.starttls()
            server.login(smtp_config['email'], smtp_config['password'])
            
            text = msg.as_string()
            server.sendmail(smtp_config['email'], invoice['client_email'], text)
            server.quit()
            
            # Mark reminder as sent
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE payment_reminders 
                SET sent = TRUE 
                WHERE invoice_id = ? AND reminder_date = date('now')
            ''', (invoice_id,))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            print(f"Error sending payment reminder: {e}")
            return False
    
    def get_invoice_analytics(self):
        """Get invoice analytics and metrics"""
        conn = sqlite3.connect(self.db_path)
        
        analytics = {}
        
        # Total invoices
        total_invoices = pd.read_sql_query("SELECT COUNT(*) as count FROM invoices", conn)
        analytics['total_invoices'] = total_invoices['count'].iloc[0]
        
        # Pending amount
        pending_amount = pd.read_sql_query('''
            SELECT SUM(amount) as total FROM invoices WHERE status = 'pending'
        ''', conn)
        analytics['pending_amount'] = pending_amount['total'].iloc[0] or 0
        
        # Overdue amount
        overdue_amount = pd.read_sql_query('''
            SELECT SUM(amount) as total FROM invoices 
            WHERE status = 'pending' AND date(due_date) < date('now')
        ''', conn)
        analytics['overdue_amount'] = overdue_amount['total'].iloc[0] or 0
        
        # Average payment time
        avg_payment_time = pd.read_sql_query('''
            SELECT AVG(julianday(date('now')) - julianday(issue_date)) as avg_days
            FROM invoices WHERE status = 'paid'
        ''', conn)
        analytics['avg_payment_days'] = avg_payment_time['avg_days'].iloc[0] or 0
        
        # Monthly invoice trends
        monthly_trends = pd.read_sql_query('''
            SELECT strftime('%Y-%m', issue_date) as month,
                   COUNT(*) as invoice_count,
                   SUM(amount) as total_amount
            FROM invoices
            GROUP BY strftime('%Y-%m', issue_date)
            ORDER BY month DESC
            LIMIT 12
        ''', conn)
        analytics['monthly_trends'] = monthly_trends.to_dict('records')
        
        conn.close()
        
        return analytics
    
    def generate_invoice_report(self, start_date, end_date):
        """Generate comprehensive invoice report"""
        conn = sqlite3.connect(self.db_path)
        
        report_query = '''
            SELECT i.invoice_number, i.client_name, i.amount, i.issue_date, 
                   i.due_date, i.status,
                   CASE 
                       WHEN i.status = 'paid' THEN 'On Time'
                       WHEN date(i.due_date) < date('now') THEN 'Overdue'
                       ELSE 'Pending'
                   END as payment_status
            FROM invoices i
            WHERE i.issue_date BETWEEN ? AND ?
            ORDER BY i.issue_date DESC
        '''
        
        report_df = pd.read_sql_query(report_query, conn, params=(start_date, end_date))
        conn.close()
        
        return report_df

# Automated reminder system
class PaymentReminderSystem:
    """Automated system for sending payment reminders"""
    
    def __init__(self, invoice_manager, smtp_config):
        self.invoice_manager = invoice_manager
        self.smtp_config = smtp_config
    
    def check_and_send_reminders(self):
        """Check for due reminders and send them"""
        try:
            conn = sqlite3.connect(self.invoice_manager.db_path)
            
            # Get reminders due today that haven't been sent
            reminders_query = '''
                SELECT pr.id, pr.invoice_id, pr.reminder_type, i.client_name
                FROM payment_reminders pr
                JOIN invoices i ON pr.invoice_id = i.id
                WHERE pr.reminder_date = date('now') 
                AND pr.sent = FALSE
                AND i.status = 'pending'
            '''
            
            reminders_df = pd.read_sql_query(reminders_query, conn)
            conn.close()
            
            sent_count = 0
            
            for _, reminder in reminders_df.iterrows():
                success = self.invoice_manager.send_payment_reminder(
                    reminder['invoice_id'], 
                    self.smtp_config
                )
                
                if success:
                    sent_count += 1
                    print(f"Sent {reminder['reminder_type']} reminder for {reminder['client_name']}")
            
            return sent_count
            
        except Exception as e:
            print(f"Error checking reminders: {e}")
            return 0

if __name__ == "__main__":
    # Test the invoice manager
    invoice_manager = InvoiceManager()
    
    # Create a sample invoice
    sample_items = [
        {'description': 'Web Development Services', 'quantity': 40, 'unit_price': 75.00},
        {'description': 'Domain Registration', 'quantity': 1, 'unit_price': 15.00}
    ]
    
    invoice_number = invoice_manager.create_invoice(
        client_name="ABC Company",
        client_email="billing@abccompany.com",
        items=sample_items,
        payment_terms=30,
        description="Monthly web development services"
    )
    
    print(f"Created invoice: {invoice_number}")
    
    # Get analytics
    analytics = invoice_manager.get_invoice_analytics()
    print(f"Invoice analytics: {analytics}")
