import requests
from bs4 import BeautifulSoup
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import json
import time
import sqlite3

class FinancialDataScraper:
    """
    Web scraper for collecting financial data from various sources
    """
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def scrape_market_data(self, symbols=['SPY', 'QQQ', 'IWM']):
        """
        Scrape market data for economic indicators
        """
        market_data = {}
        
        try:
            for symbol in symbols:
                ticker = yf.Ticker(symbol)
                hist = ticker.history(period="1mo")
                
                if not hist.empty:
                    current_price = hist['Close'].iloc[-1]
                    prev_price = hist['Close'].iloc[-2] if len(hist) > 1 else current_price
                    change_pct = ((current_price - prev_price) / prev_price) * 100
                    
                    market_data[symbol] = {
                        'price': current_price,
                        'change_percent': change_pct,
                        'volume': hist['Volume'].iloc[-1],
                        'last_updated': datetime.now().isoformat()
                    }
            
            return market_data
        
        except Exception as e:
            print(f"Error scraping market data: {e}")
            return {}
    
    def scrape_economic_indicators(self):
        """
        Scrape economic indicators that might affect small businesses
        """
        indicators = {}
        
        try:
            # Federal Reserve Economic Data (FRED) - simplified approach
            # In a real implementation, you'd use FRED API
            
            # Mock data for demonstration
            indicators = {
                'inflation_rate': 3.2,
                'unemployment_rate': 3.7,
                'gdp_growth': 2.1,
                'interest_rate': 5.25,
                'last_updated': datetime.now().isoformat()
            }
            
            return indicators
        
        except Exception as e:
            print(f"Error scraping economic indicators: {e}")
            return {}
    
    def scrape_industry_trends(self, industry="small_business"):
        """
        Scrape industry-specific trends and benchmarks
        """
        trends = {}
        
        try:
            # This would typically scrape from industry reports, news sites, etc.
            # Mock data for demonstration
            
            trends = {
                'average_profit_margin': 15.2,
                'seasonal_peak_months': ['November', 'December'],
                'growth_rate': 8.5,
                'cash_flow_cycle_days': 45,
                'last_updated': datetime.now().isoformat()
            }
            
            return trends
        
        except Exception as e:
            print(f"Error scraping industry trends: {e}")
            return {}
    
    def scrape_tax_deadlines(self, year=None):
        """
        Scrape current tax deadlines from IRS website
        """
        if year is None:
            year = datetime.now().year
        
        tax_deadlines = []
        
        try:
            # Mock tax deadlines - in real implementation, scrape from IRS website
            deadlines = [
                {
                    'date': f'{year}-01-31',
                    'description': 'Form 940 (Annual Federal Unemployment Tax)',
                    'type': 'Federal',
                    'applies_to': 'Employers'
                },
                {
                    'date': f'{year}-03-15',
                    'description': 'S Corporation Tax Return (Form 1120S)',
                    'type': 'Federal',
                    'applies_to': 'S Corporations'
                },
                {
                    'date': f'{year}-04-15',
                    'description': 'Individual Income Tax Return (Form 1040)',
                    'type': 'Federal',
                    'applies_to': 'Individuals'
                },
                {
                    'date': f'{year}-04-15',
                    'description': 'Partnership Tax Return (Form 1065)',
                    'type': 'Federal',
                    'applies_to': 'Partnerships'
                },
                {
                    'date': f'{year}-06-15',
                    'description': 'Quarterly Estimated Tax Payment (Q2)',
                    'type': 'Federal',
                    'applies_to': 'Self-employed'
                },
                {
                    'date': f'{year}-09-15',
                    'description': 'Quarterly Estimated Tax Payment (Q3)',
                    'type': 'Federal',
                    'applies_to': 'Self-employed'
                }
            ]
            
            return deadlines
        
        except Exception as e:
            print(f"Error scraping tax deadlines: {e}")
            return []
    
    def scrape_bank_rates(self):
        """
        Scrape current bank interest rates for business accounts
        """
        rates = {}
        
        try:
            # Mock bank rates - in real implementation, scrape from bank websites
            rates = {
                'business_savings': {
                    'average_rate': 0.45,
                    'best_rate': 1.25,
                    'last_updated': datetime.now().isoformat()
                },
                'business_checking': {
                    'average_rate': 0.05,
                    'best_rate': 0.25,
                    'last_updated': datetime.now().isoformat()
                },
                'business_cd_1year': {
                    'average_rate': 2.15,
                    'best_rate': 3.25,
                    'last_updated': datetime.now().isoformat()
                },
                'sba_loan_rates': {
                    'average_rate': 11.5,
                    'range': '10.25% - 13.75%',
                    'last_updated': datetime.now().isoformat()
                }
            }
            
            return rates
        
        except Exception as e:
            print(f"Error scraping bank rates: {e}")
            return {}
    
    def scrape_competitor_pricing(self, industry, location=None):
        """
        Scrape competitor pricing information
        """
        pricing_data = {}
        
        try:
            # Mock competitor pricing - in real implementation, scrape from various sources
            pricing_data = {
                'average_service_price': 125.00,
                'price_range': {'min': 75.00, 'max': 200.00},
                'market_position': 'competitive',
                'pricing_trends': 'increasing',
                'last_updated': datetime.now().isoformat()
            }
            
            return pricing_data
        
        except Exception as e:
            print(f"Error scraping competitor pricing: {e}")
            return {}
    
    def update_database_with_scraped_data(self):
        """
        Update the database with all scraped financial data
        """
        try:
            conn = sqlite3.connect('finance_data.db')
            cursor = conn.cursor()
            
            # Create table for external data if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS external_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    data_type TEXT NOT NULL,
                    data_json TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Scrape and store market data
            market_data = self.scrape_market_data()
            if market_data:
                cursor.execute('''
                    INSERT INTO external_data (data_type, data_json)
                    VALUES (?, ?)
                ''', ('market_data', json.dumps(market_data)))
            
            # Scrape and store economic indicators
            economic_data = self.scrape_economic_indicators()
            if economic_data:
                cursor.execute('''
                    INSERT INTO external_data (data_type, data_json)
                    VALUES (?, ?)
                ''', ('economic_indicators', json.dumps(economic_data)))
            
            # Scrape and store industry trends
            industry_data = self.scrape_industry_trends()
            if industry_data:
                cursor.execute('''
                    INSERT INTO external_data (data_type, data_json)
                    VALUES (?, ?)
                ''', ('industry_trends', json.dumps(industry_data)))
            
            # Scrape and store tax deadlines
            tax_data = self.scrape_tax_deadlines()
            if tax_data:
                cursor.execute('''
                    INSERT INTO external_data (data_type, data_json)
                    VALUES (?, ?)
                ''', ('tax_deadlines', json.dumps(tax_data)))
            
            # Scrape and store bank rates
            bank_rates = self.scrape_bank_rates()
            if bank_rates:
                cursor.execute('''
                    INSERT INTO external_data (data_type, data_json)
                    VALUES (?, ?)
                ''', ('bank_rates', json.dumps(bank_rates)))
            
            conn.commit()
            conn.close()
            
            print("Successfully updated database with scraped financial data")
            return True
            
        except Exception as e:
            print(f"Error updating database: {e}")
            return False

# Automated scraping scheduler
class DataScrapingScheduler:
    """
    Schedule regular data scraping tasks
    """
    
    def __init__(self):
        self.scraper = FinancialDataScraper()
    
    def schedule_daily_updates(self):
        """
        Schedule daily data updates
        """
        import schedule
        
        # Schedule market data updates every hour during market hours
        schedule.every().hour.at(":00").do(self.update_market_data)
        
        # Schedule economic data updates daily at 6 AM
        schedule.every().day.at("06:00").do(self.update_economic_data)
        
        # Schedule tax deadline updates weekly
        schedule.every().monday.at("07:00").do(self.update_tax_deadlines)
        
        print("Data scraping scheduler initialized")
    
    def update_market_data(self):
        """Update market data"""
        try:
            market_data = self.scraper.scrape_market_data()
            print(f"Market data updated: {len(market_data)} symbols")
        except Exception as e:
            print(f"Error updating market data: {e}")
    
    def update_economic_data(self):
        """Update economic indicators"""
        try:
            economic_data = self.scraper.scrape_economic_indicators()
            print("Economic indicators updated")
        except Exception as e:
            print(f"Error updating economic data: {e}")
    
    def update_tax_deadlines(self):
        """Update tax deadlines"""
        try:
            tax_data = self.scraper.scrape_tax_deadlines()
            print(f"Tax deadlines updated: {len(tax_data)} deadlines")
        except Exception as e:
            print(f"Error updating tax deadlines: {e}")
    
    def run_scheduler(self):
        """Run the scheduler in a separate thread"""
        import threading
        
        def run_schedule():
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        
        scheduler_thread = threading.Thread(target=run_schedule, daemon=True)
        scheduler_thread.start()
        print("Data scraping scheduler started in background")

if __name__ == "__main__":
    # Test the scraper
    scraper = FinancialDataScraper()
    
    print("Testing web scraper...")
    
    # Test market data scraping
    market_data = scraper.scrape_market_data()
    print(f"Market data: {market_data}")
    
    # Test economic indicators
    economic_data = scraper.scrape_economic_indicators()
    print(f"Economic data: {economic_data}")
    
    # Test tax deadlines
    tax_deadlines = scraper.scrape_tax_deadlines()
    print(f"Tax deadlines: {len(tax_deadlines)} found")
    
    # Update database
    success = scraper.update_database_with_scraped_data()
    print(f"Database update: {'Success' if success else 'Failed'}")
