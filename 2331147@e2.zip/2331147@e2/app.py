import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import sqlite3
import json
import requests
from bs4 import BeautifulSoup
import yfinance as yf
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
import smtplib
from email.mime.text import MIMEText
import schedule
import time
import threading
from invoice_manager import InvoiceManager

# Page configuration
st.set_page_config(
    page_title="FinanceFlow - Small Business Financial Management",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 4px solid #667eea;
    }
    .alert-box {
        padding: 1rem;
        border-radius: 5px;
        margin: 1rem 0;
    }
    .alert-warning {
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        color: #856404;
    }
    .alert-success {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
    }
</style>
""", unsafe_allow_html=True)

# Database initialization
def init_database():
    conn = sqlite3.connect('finance_data.db')
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL,
            revenue_stream TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS revenue_streams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            monthly_target REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tax_deadlines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            deadline_date TEXT NOT NULL,
            description TEXT NOT NULL,
            amount REAL,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS financial_goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            goal_name TEXT NOT NULL,
            target_amount REAL NOT NULL,
            current_amount REAL DEFAULT 0,
            target_date TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

# Initialize database
init_database()

# Seed sample data for all features if database is empty
def seed_sample_data():
    conn = sqlite3.connect('finance_data.db')
    cursor = conn.cursor()

    # Seed revenue streams
    cursor.execute("SELECT COUNT(*) FROM revenue_streams")
    if cursor.fetchone()[0] == 0:
        streams = [
            ("Online Sales", "E-commerce storefront", 50000),
            ("Retail Store", "In-store purchases", 30000),
            ("Services", "Consulting and implementation", 20000),
        ]
        cursor.executemany(
            "INSERT INTO revenue_streams (name, description, monthly_target) VALUES (?, ?, ?)",
            streams,
        )

    # Seed transactions for current and previous month
    cursor.execute("SELECT COUNT(*) FROM transactions")
    if cursor.fetchone()[0] == 0:
        today = datetime.now().date()
        first_day_this_month = today.replace(day=1)
        prev_month_last_day = first_day_this_month - timedelta(days=1)
        first_day_prev_month = prev_month_last_day.replace(day=1)

        txns = [
            # Current month revenues
            (today.isoformat(), "Shopify Sales", "Revenue", 18250.75, "Online Sales"),
            (today.isoformat(), "In-store Sales", "Revenue", 13220.10, "Retail Store"),
            ((today - timedelta(days=3)).isoformat(), "Consulting Invoice", "Revenue", 5400.00, "Services"),
            # Current month expenses
            ((today - timedelta(days=2)).isoformat(), "Inventory Purchase", "COGS", -7200.25, "Retail Store"),
            ((today - timedelta(days=5)).isoformat(), "Ads - Meta", "Marketing", -1250.00, "Online Sales"),
            ((today - timedelta(days=7)).isoformat(), "SaaS Subscriptions", "Overheads", -399.00, None),
            # Previous month
            (first_day_prev_month.isoformat(), "Opening Balance", "Revenue", 10000.00, None),
            ((first_day_prev_month + timedelta(days=5)).isoformat(), "Rent", "Overheads", -2500.00, None),
            ((first_day_prev_month + timedelta(days=12)).isoformat(), "Stripe Payout", "Revenue", 8500.00, "Online Sales"),
            ((first_day_prev_month + timedelta(days=18)).isoformat(), "Utilities", "Overheads", -480.75, None),
        ]
        cursor.executemany(
            "INSERT INTO transactions (date, description, category, amount, revenue_stream) VALUES (?, ?, ?, ?, ?)",
            txns,
        )

    # Seed tax deadlines
    cursor.execute("SELECT COUNT(*) FROM tax_deadlines")
    if cursor.fetchone()[0] == 0:
        year = datetime.now().year
        deadlines = [
            (f"{year}-01-31", "Form 940 (FUTA) Annual Filing", 0.0, "pending"),
            (f"{year}-04-15", "Quarterly Estimated Tax (Q1)", 3500.00, "pending"),
            (f"{year}-06-15", "Quarterly Estimated Tax (Q2)", 3600.00, "pending"),
            (f"{year}-09-15", "Quarterly Estimated Tax (Q3)", 3700.00, "pending"),
            (f"{year}-12-31", "Year-End Payroll Filings", 0.0, "pending"),
        ]
        cursor.executemany(
            "INSERT INTO tax_deadlines (deadline_date, description, amount, status) VALUES (?, ?, ?, ?)",
            deadlines,
        )

    # Seed financial goals
    cursor.execute("SELECT COUNT(*) FROM financial_goals")
    if cursor.fetchone()[0] == 0:
        goals = [
            ("Increase Monthly Revenue", 100000.0, 42500.0, (datetime.now() + timedelta(days=120)).strftime('%Y-%m-%d')),
            ("Reduce Overheads by 15%", 15000.0, 4000.0, (datetime.now() + timedelta(days=180)).strftime('%Y-%m-%d')),
            ("Build Cash Reserve", 50000.0, 12000.0, (datetime.now() + timedelta(days=240)).strftime('%Y-%m-%d')),
        ]
        cursor.executemany(
            "INSERT INTO financial_goals (goal_name, target_amount, current_amount, target_date) VALUES (?, ?, ?, ?)",
            goals,
        )

    conn.commit()
    conn.close()

    # Seed invoices via InvoiceManager (also ensures invoice tables exist)
    inv = InvoiceManager()
    try:
        pending_df = inv.get_pending_invoices()
        if pending_df.empty:
            inv.create_invoice(
                client_name="Acme Corp",
                client_email="billing@acme.example",
                items=[
                    {"description": "Implementation", "quantity": 10, "unit_price": 150.0},
                    {"description": "Training", "quantity": 2, "unit_price": 500.0},
                ],
                payment_terms=30,
                description="Initial rollout"
            )
            inv.create_invoice(
                client_name="Globex LLC",
                client_email="accounts@globex.example",
                items=[
                    {"description": "Consulting", "quantity": 8, "unit_price": 200.0},
                ],
                payment_terms=14,
                description="Quarterly advisory"
            )
    except Exception as e:
        print(f"Invoice seeding skipped due to error: {e}")

# Run seed on startup (idempotent: only inserts when empty)
seed_sample_data()

# Sidebar navigation
st.sidebar.title("🏦 FinanceFlow")
st.sidebar.markdown("---")

# Support deep-linking via query parameter ?page=...
pages = [
    "Dashboard",
    "Cash Flow",
    "Revenue Streams",
    "Forecasting",
    "Tax Calendar",
    "Invoice Management",
    "Financial Goals",
    "Reports",
    "Settings",
]

# Read page from query params (prefer st.query_params; fallback to experimental for older versions)
try:
    params = st.query_params  # type: ignore[attr-defined]
except Exception:
    # Fallback to deprecated API if running on older Streamlit
    try:
        params = st.experimental_get_query_params()  # type: ignore[attr-defined]
    except Exception:
        params = {}

requested_page = None
if isinstance(params, dict):
    # experimental_get_query_params returns lists; st.query_params returns Mapping
    val = params.get("page")
    if isinstance(val, list):
        requested_page = val[0]
    elif isinstance(val, str):
        requested_page = val

default_index = 0
if requested_page in pages:
    default_index = pages.index(requested_page)

page = st.sidebar.selectbox(
    "Navigate to:",
    pages,
    index=default_index,
)

# Sync current page to query params for shareable links
try:
    st.query_params["page"] = page  # type: ignore[attr-defined]
except Exception:
    try:
        st.experimental_set_query_params(page=page)  # type: ignore[attr-defined]
    except Exception:
        pass

# Main header
st.markdown("""
<div class="main-header">
    <h1>🚀 FinanceFlow - Smart Financial Management</h1>
    <p>Empowering small businesses with AI-driven financial insights</p>
</div>
""", unsafe_allow_html=True)

# Dashboard Page
if page == "Dashboard":
    st.header("📊 Financial Dashboard")
    
    # Key metrics row
    col1, col2, col3, col4 = st.columns(4)
    
    # Sample data for demonstration
    conn = sqlite3.connect('finance_data.db')
    
    # Calculate metrics
    current_month = datetime.now().strftime('%Y-%m')
    
    # Current cash flow
    cash_flow_query = f"""
        SELECT COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) - 
               COALESCE(SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END), 0) as cash_flow
        FROM transactions 
        WHERE strftime('%Y-%m', date) = '{current_month}'
    """
    cash_flow = pd.read_sql_query(cash_flow_query, conn)
    current_cash_flow = cash_flow['cash_flow'].iloc[0] if not cash_flow.empty else 0
    # Guard against None/NaN values to avoid formatting errors
    try:
        if current_cash_flow is None or (isinstance(current_cash_flow, float) and np.isnan(current_cash_flow)):
            current_cash_flow = 0.0
        else:
            current_cash_flow = float(current_cash_flow)
    except Exception:
        current_cash_flow = 0.0
    
    with col1:
        st.metric(
            label="💰 Current Cash Flow",
            value=f"${current_cash_flow:,.2f}",
            delta="12.5%"
        )
    
    with col2:
        st.metric(
            label="📈 Monthly Revenue",
            value="$45,230",
            delta="8.2%"
        )
    
    with col3:
        st.metric(
            label="⚠️ Tax Deadlines",
            value="3",
            delta="-1"
        )
    
    with col4:
        st.metric(
            label="🎯 Goal Progress",
            value="78%",
            delta="5%"
        )
    
    # Charts row
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("💹 Cash Flow Trend")
        # Generate sample data
        dates = pd.date_range(start='2024-01-01', end='2024-12-31', freq='M')
        cash_flow_data = np.random.normal(15000, 5000, len(dates))
        
        fig = px.line(
            x=dates, 
            y=cash_flow_data,
            title="Monthly Cash Flow",
            labels={'x': 'Month', 'y': 'Cash Flow ($)'}
        )
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("🥧 Revenue by Stream")
        revenue_data = {
            'Stream': ['Product Sales', 'Services', 'Consulting', 'Subscriptions'],
            'Revenue': [25000, 18000, 12000, 8000]
        }
        fig = px.pie(
            values=revenue_data['Revenue'],
            names=revenue_data['Stream'],
            title="Revenue Distribution"
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Recent transactions and alerts
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📋 Recent Transactions")
        recent_transactions = pd.read_sql_query(
            "SELECT * FROM transactions ORDER BY created_at DESC LIMIT 5", 
            conn
        )
        if not recent_transactions.empty:
            st.dataframe(recent_transactions[['date', 'description', 'category', 'amount']])
        else:
            st.info("No transactions found. Add some transactions to see them here.")
    
    with col2:
        st.subheader("🔔 Alerts & Notifications")
        st.markdown("""
        <div class="alert-box alert-warning">
            <strong>⚠️ Budget Alert:</strong> Marketing expenses are 15% over budget this month.
        </div>
        <div class="alert-box alert-success">
            <strong>✅ Goal Achievement:</strong> Q4 revenue target reached!
        </div>
        """, unsafe_allow_html=True)
    
    conn.close()

# Cash Flow Page
elif page == "Cash Flow":
    st.header("💰 Cash Flow Management")
    
    # Add transaction form
    with st.expander("➕ Add New Transaction"):
        with st.form("transaction_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                trans_date = st.date_input("Date", datetime.now())
                description = st.text_input("Description")
                category = st.selectbox("Category", ["Revenue", "Expenses", "Investment", "Tax Payment"])
            
            with col2:
                amount = st.number_input("Amount ($)", step=0.01)
                revenue_stream = st.text_input("Revenue Stream (optional)")
            
            if st.form_submit_button("Add Transaction"):
                conn = sqlite3.connect('finance_data.db')
                cursor = conn.cursor()
                
                # Adjust amount based on category
                final_amount = amount if category == "Revenue" else -abs(amount)
                
                cursor.execute('''
                    INSERT INTO transactions (date, description, category, amount, revenue_stream)
                    VALUES (?, ?, ?, ?, ?)
                ''', (trans_date.strftime('%Y-%m-%d'), description, category, final_amount, revenue_stream))
                
                conn.commit()
                conn.close()
                st.success("Transaction added successfully!")
                st.experimental_rerun()
    
    # Cash flow visualization
    conn = sqlite3.connect('finance_data.db')
    transactions_df = pd.read_sql_query("SELECT * FROM transactions ORDER BY date", conn)
    
    if not transactions_df.empty:
        transactions_df['date'] = pd.to_datetime(transactions_df['date'])
        transactions_df['cumulative_balance'] = transactions_df['amount'].cumsum()
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=transactions_df['date'],
            y=transactions_df['cumulative_balance'],
            mode='lines+markers',
            name='Cash Flow',
            line=dict(color='#667eea', width=3)
        ))
        
        fig.update_layout(
            title="Cash Flow Over Time",
            xaxis_title="Date",
            yaxis_title="Cumulative Balance ($)",
            hovermode='x unified'
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Transactions table
        st.subheader("📊 Transaction History")
        st.dataframe(transactions_df[['date', 'description', 'category', 'amount', 'revenue_stream']])
    else:
        st.info("No transactions found. Add some transactions to see cash flow analysis.")
    
    conn.close()

# Revenue Streams Page
elif page == "Revenue Streams":
    st.header("🌊 Revenue Streams Management")
    
    # Add revenue stream
    with st.expander("➕ Add New Revenue Stream"):
        with st.form("revenue_stream_form"):
            stream_name = st.text_input("Stream Name")
            stream_description = st.text_area("Description")
            monthly_target = st.number_input("Monthly Target ($)", step=0.01)
            
            if st.form_submit_button("Add Revenue Stream"):
                conn = sqlite3.connect('finance_data.db')
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO revenue_streams (name, description, monthly_target)
                    VALUES (?, ?, ?)
                ''', (stream_name, stream_description, monthly_target))
                
                conn.commit()
                conn.close()
                st.success("Revenue stream added successfully!")
                st.experimental_rerun()
    
    # Display revenue streams
    conn = sqlite3.connect('finance_data.db')
    streams_df = pd.read_sql_query("SELECT * FROM revenue_streams", conn)
    
    if not streams_df.empty:
        for _, stream in streams_df.iterrows():
            with st.container():
                col1, col2, col3 = st.columns([2, 1, 1])
                
                with col1:
                    st.subheader(stream['name'])
                    st.write(stream['description'])
                
                with col2:
                    st.metric("Monthly Target", f"${stream['monthly_target']:,.2f}")
                
                with col3:
                    # Calculate actual revenue for this stream
                    actual_revenue = pd.read_sql_query(f"""
                        SELECT SUM(amount) as total 
                        FROM transactions 
                        WHERE revenue_stream = '{stream['name']}' 
                        AND strftime('%Y-%m', date) = '{datetime.now().strftime('%Y-%m')}'
                    """, conn)
                    
                    actual = actual_revenue['total'].iloc[0] if actual_revenue['total'].iloc[0] else 0
                    st.metric("This Month", f"${actual:,.2f}")
                
                st.markdown("---")
    else:
        st.info("No revenue streams found. Add some revenue streams to track performance.")
    
    conn.close()

# Continue with other pages...
elif page == "Forecasting":
    st.header("🔮 Financial Forecasting")
    
    # Forecasting controls
    col1, col2, col3 = st.columns(3)
    
    with col1:
        forecast_period = st.selectbox("Forecast Period", ["3 Months", "6 Months", "12 Months"])
    
    with col2:
        include_seasonality = st.checkbox("Include Seasonal Trends", value=True)
    
    with col3:
        confidence_level = st.slider("Confidence Level", 80, 99, 95)
    
    # Generate forecast
    if st.button("🎯 Generate Forecast"):
        # Sample forecasting logic
        conn = sqlite3.connect('finance_data.db')
        historical_data = pd.read_sql_query("""
            SELECT date, SUM(amount) as daily_total 
            FROM transactions 
            GROUP BY date 
            ORDER BY date
        """, conn)
        
        if not historical_data.empty:
            # Simple linear regression forecast
            historical_data['date'] = pd.to_datetime(historical_data['date'])
            historical_data['days'] = (historical_data['date'] - historical_data['date'].min()).dt.days
            
            X = historical_data[['days']]
            y = historical_data['daily_total']
            
            model = LinearRegression()
            model.fit(X, y)
            
            # Forecast future dates
            periods = {"3 Months": 90, "6 Months": 180, "12 Months": 365}
            future_days = periods[forecast_period]
            
            last_day = historical_data['days'].max()
            future_X = np.array([[last_day + i] for i in range(1, future_days + 1)])
            forecast = model.predict(future_X)
            
            # Create forecast visualization
            future_dates = pd.date_range(
                start=historical_data['date'].max() + timedelta(days=1),
                periods=future_days,
                freq='D'
            )
            
            fig = go.Figure()
            
            # Historical data
            fig.add_trace(go.Scatter(
                x=historical_data['date'],
                y=historical_data['daily_total'],
                mode='lines',
                name='Historical',
                line=dict(color='blue')
            ))
            
            # Forecast
            fig.add_trace(go.Scatter(
                x=future_dates,
                y=forecast,
                mode='lines',
                name='Forecast',
                line=dict(color='red', dash='dash')
            ))
            
            fig.update_layout(
                title=f"Financial Forecast - {forecast_period}",
                xaxis_title="Date",
                yaxis_title="Daily Total ($)",
                hovermode='x unified'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Forecast insights
            st.subheader("📈 Forecast Insights")
            total_forecast = forecast.sum()
            avg_daily = forecast.mean()
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Forecast", f"${total_forecast:,.2f}")
            
            with col2:
                st.metric("Average Daily", f"${avg_daily:,.2f}")
            
            with col3:
                growth_rate = ((forecast[-1] - forecast[0]) / forecast[0]) * 100
                st.metric("Growth Rate", f"{growth_rate:.1f}%")
        
        else:
            st.warning("Not enough historical data for forecasting. Add more transactions.")
        
        conn.close()

elif page == "Tax Calendar":
    st.header("📅 Tax Calendar & Deadlines")
    
    # Add tax deadline
    with st.expander("➕ Add Tax Deadline"):
        with st.form("tax_deadline_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                deadline_date = st.date_input("Deadline Date")
                description = st.text_input("Description")
            
            with col2:
                amount = st.number_input("Estimated Amount ($)", step=0.01)
                status = st.selectbox("Status", ["Pending", "Completed", "Overdue"])
            
            if st.form_submit_button("Add Deadline"):
                conn = sqlite3.connect('finance_data.db')
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO tax_deadlines (deadline_date, description, amount, status)
                    VALUES (?, ?, ?, ?)
                ''', (deadline_date.strftime('%Y-%m-%d'), description, amount, status))
                
                conn.commit()
                conn.close()
                st.success("Tax deadline added successfully!")
                st.experimental_rerun()
    
    # Display upcoming deadlines
    conn = sqlite3.connect('finance_data.db')
    deadlines_df = pd.read_sql_query("""
        SELECT * FROM tax_deadlines 
        WHERE deadline_date >= date('now') 
        ORDER BY deadline_date
    """, conn)
    
    if not deadlines_df.empty:
        st.subheader("⏰ Upcoming Deadlines")
        
        for _, deadline in deadlines_df.iterrows():
            days_until = (pd.to_datetime(deadline['deadline_date']) - pd.Timestamp.now()).days
            
            if days_until <= 7:
                alert_type = "🔴"
            elif days_until <= 30:
                alert_type = "🟡"
            else:
                alert_type = "🟢"
            
            st.markdown(f"""
            **{alert_type} {deadline['description']}**
            - Date: {deadline['deadline_date']}
            - Amount: ${deadline['amount']:,.2f}
            - Days until deadline: {days_until}
            - Status: {deadline['status']}
            """)
            st.markdown("---")
    else:
        st.info("No upcoming tax deadlines found.")
    
    conn.close()

elif page == "Financial Goals":
    st.header("🎯 Financial Goals")
    
    # Add financial goal
    with st.expander("➕ Set New Financial Goal"):
        with st.form("goal_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                goal_name = st.text_input("Goal Name")
                target_amount = st.number_input("Target Amount ($)", step=0.01)
            
            with col2:
                current_amount = st.number_input("Current Amount ($)", step=0.01)
                target_date = st.date_input("Target Date")
            
            if st.form_submit_button("Set Goal"):
                conn = sqlite3.connect('finance_data.db')
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO financial_goals (goal_name, target_amount, current_amount, target_date)
                    VALUES (?, ?, ?, ?)
                ''', (goal_name, target_amount, current_amount, target_date.strftime('%Y-%m-%d')))
                
                conn.commit()
                conn.close()
                st.success("Financial goal set successfully!")
                st.experimental_rerun()
    
    # Display goals
    conn = sqlite3.connect('finance_data.db')
    goals_df = pd.read_sql_query("SELECT * FROM financial_goals ORDER BY target_date", conn)
    
    if not goals_df.empty:
        for _, goal in goals_df.iterrows():
            progress = (goal['current_amount'] / goal['target_amount']) * 100
            
            st.subheader(goal['goal_name'])
            st.progress(min(progress / 100, 1.0))
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Progress", f"{progress:.1f}%")
            
            with col2:
                st.metric("Current", f"${goal['current_amount']:,.2f}")
            
            with col3:
                st.metric("Target", f"${goal['target_amount']:,.2f}")
            
            st.write(f"Target Date: {goal['target_date']}")
            st.markdown("---")
    else:
        st.info("No financial goals set. Create some goals to track your progress.")
    
    conn.close()

elif page == "Reports":
    st.header("📊 Financial Reports")
    
    report_type = st.selectbox(
        "Select Report Type",
        ["Profit & Loss", "Cash Flow Statement", "Revenue Analysis", "Expense Breakdown", "Tax Summary"]
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        start_date = st.date_input("Start Date", datetime.now() - timedelta(days=30))
    
    with col2:
        end_date = st.date_input("End Date", datetime.now())
    
    if st.button("📈 Generate Report"):
        conn = sqlite3.connect('finance_data.db')
        
        if report_type == "Profit & Loss":
            revenue_query = f"""
                SELECT SUM(amount) as total_revenue 
                FROM transactions 
                WHERE amount > 0 AND date BETWEEN '{start_date}' AND '{end_date}'
            """
            
            expenses_query = f"""
                SELECT SUM(ABS(amount)) as total_expenses 
                FROM transactions 
                WHERE amount < 0 AND date BETWEEN '{start_date}' AND '{end_date}'
            """
            
            revenue = pd.read_sql_query(revenue_query, conn)['total_revenue'].iloc[0] or 0
            expenses = pd.read_sql_query(expenses_query, conn)['total_expenses'].iloc[0] or 0
            profit = revenue - expenses
            
            st.subheader("💰 Profit & Loss Statement")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Revenue", f"${revenue:,.2f}")
            
            with col2:
                st.metric("Total Expenses", f"${expenses:,.2f}")
            
            with col3:
                st.metric("Net Profit", f"${profit:,.2f}", delta=f"{((profit/revenue)*100):.1f}%" if revenue > 0 else "0%")
        
        elif report_type == "Cash Flow Statement":
            transactions = pd.read_sql_query(f"""
                SELECT date, category, SUM(amount) as amount 
                FROM transactions 
                WHERE date BETWEEN '{start_date}' AND '{end_date}'
                GROUP BY date, category
                ORDER BY date
            """, conn)
            
            if not transactions.empty:
                st.subheader("💹 Cash Flow Statement")
                
                fig = px.bar(
                    transactions,
                    x='date',
                    y='amount',
                    color='category',
                    title="Daily Cash Flow by Category"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                st.dataframe(transactions)
        
        conn.close()

elif page == "Settings":
    st.header("⚙️ Settings")
    
    st.subheader("📧 Email Notifications")
    
    col1, col2 = st.columns(2)
    
    with col1:
        email_address = st.text_input("Email Address")
        enable_alerts = st.checkbox("Enable Budget Alerts")
        enable_deadlines = st.checkbox("Enable Tax Deadline Reminders")
    
    with col2:
        smtp_server = st.text_input("SMTP Server", value="smtp.gmail.com")
        smtp_port = st.number_input("SMTP Port", value=587)
    
    st.subheader("🔗 Bank Integration")
    st.info("Bank integration feature coming soon! This will allow automatic transaction import.")
    
    st.subheader("💾 Data Management")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("📥 Export Data"):
            conn = sqlite3.connect('finance_data.db')
            
            # Export all data to Excel
            with pd.ExcelWriter('financial_data_export.xlsx') as writer:
                transactions_df = pd.read_sql_query("SELECT * FROM transactions", conn)
                revenue_streams_df = pd.read_sql_query("SELECT * FROM revenue_streams", conn)
                tax_deadlines_df = pd.read_sql_query("SELECT * FROM tax_deadlines", conn)
                goals_df = pd.read_sql_query("SELECT * FROM financial_goals", conn)
                
                transactions_df.to_excel(writer, sheet_name='Transactions', index=False)
                revenue_streams_df.to_excel(writer, sheet_name='Revenue Streams', index=False)
                tax_deadlines_df.to_excel(writer, sheet_name='Tax Deadlines', index=False)
                goals_df.to_excel(writer, sheet_name='Financial Goals', index=False)
            
            conn.close()
            st.success("Data exported successfully!")
    
    with col2:
        uploaded_file = st.file_uploader("📤 Import Transactions", type=['csv', 'xlsx'])
        
        if uploaded_file is not None:
            if uploaded_file.name.endswith('.csv'):
                df = pd.read_csv(uploaded_file)
            else:
                df = pd.read_excel(uploaded_file)
            
            st.write("Preview of uploaded data:")
            st.dataframe(df.head())
            
            if st.button("Import Data"):
                # Import logic here
                st.success("Data imported successfully!")

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666; padding: 1rem;'>
    <p>🚀 FinanceFlow - Empowering Small Businesses with Smart Financial Management</p>
    <p>Built with ❤️ using Streamlit | © 2024 FinanceFlow</p>
</div>
""", unsafe_allow_html=True)
