import streamlit as st
from utils.ui import footer
from utils.summarize import summarize_chunks

st.set_page_config(page_title="Study Guides | Campus Learning Studio", page_icon="📖", layout="wide")

st.title("📖 Study Guides")
st.caption("Generate quick, structured study guides from your indexed course materials.")

chunks = st.session_state.get("chunks", [])
if not chunks:
    st.info("No content indexed yet. Please go to 'Uploads' and build an index or load the samples.")
else:
    with st.container(border=True):
        max_chars = st.slider("Summary length (chars)", 400, 4000, 1200, 100)
        if st.button("Generate Study Guide", use_container_width=True):
            sg = summarize_chunks(chunks, max_chars=max_chars)
            st.session_state["study_guide"] = sg

    sg = st.session_state.get("study_guide")
    if sg:
        st.subheader("Overview")
        st.write(sg.get("overview", ""))
        st.markdown("---")

        st.subheader("Key Terms")
        key_terms = sg.get("key_terms", [])
        if key_terms:
            st.write(", ".join(key_terms))
        else:
            st.caption("No terms extracted.")
        st.markdown("---")

        st.subheader("Outline")
        outline = sg.get("outline", [])
        if outline:
            for i, line in enumerate(outline, 1):
                st.write(f"{i}. {line}")
        else:
            st.caption("No outline available.")

footer()
