import streamlit as st
from utils.ui import footer
from utils.tutor import grounded_answer

st.set_page_config(page_title="Tutor Chat | Campus Learning Studio", page_icon="🤖", layout="wide")

st.title("🤖 AI Tutor (Grounded)")
st.caption("Ask questions grounded in your uploaded course materials. We'll cite exact snippets.")

index = st.session_state.get("index")
if not index:
    st.info("No index found. Please go to the 'Uploads' page and build an index first.")

with st.container(border=True):
    q = st.text_input("Your question", placeholder="e.g., Explain the difference between supervised and unsupervised learning")
    ask = st.button("Ask Tutor", use_container_width=True, disabled=not index)

if ask and q:
    result = grounded_answer(index, q)
    st.subheader("Answer")
    st.write(result.get("answer", ""))

    cites = result.get("citations", [])
    if cites:
        st.markdown("---")
        st.subheader("Citations")
        for c in cites:
            with st.container(border=True):
                st.caption(f"Source: {c.get('source')} • Page: {c.get('page')}")
                st.write(f"> {c.get('quote')}")

footer()
