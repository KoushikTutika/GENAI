import streamlit as st
from utils.ui import hero_header, footer, sidebar_branding

st.set_page_config(
    page_title="Campus Learning Studio",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

sidebar_branding()

hero_header(
    title="Campus Learning Studio",
    subtitle="AI-powered study guides, quizzes, concept maps, and tutoring — grounded in your course materials.",
    image_url="https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?q=80&w=1974&auto=format&fit=crop",
)

col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Students Supported", "15,000+")
with col2:
    st.metric("Time Saved / Faculty", "20+ hrs/week")
with col3:
    st.metric("Target: Reduce Failures", "-30%")

st.markdown("---")

st.subheader("What you can do")

features = [
    ("📚 Upload & Summarize", "Upload textbooks and papers to generate study guides."),
    ("🧠 Personalized Learning", "Create adaptive materials based on performance."),
    ("📝 Quiz Generator", "Generate MCQs and practice tests from content."),
    ("🔗 Cross-Reference Concepts", "Connect topics across courses."),
    ("🎯 Learning Objectives", "Extract objectives mapped to Bloom levels."),
    ("🗺️ Concept Maps", "Interactive concept mapping with citations."),
    ("📋 Syllabi Recommender", "Build standard-aligned syllabi."),
    ("🤖 Tutor Chat", "Ask questions grounded in your uploads with citations."),
]

cols = st.columns(4)
for i, (title, desc) in enumerate(features):
    with cols[i % 4]:
        st.container(border=True)
        st.markdown(f"**{title}**")
        st.caption(desc)

st.markdown("---")

st.info(
    "Use the sidebar to navigate features. Start with 'Uploads' to add your course materials."
)

footer()
