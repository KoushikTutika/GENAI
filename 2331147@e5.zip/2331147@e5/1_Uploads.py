import streamlit as st
from utils.ui import footer
from utils.ingestion import parse_documents
from utils.rag import build_index
from pathlib import Path

st.set_page_config(page_title="Uploads | Campus Learning Studio", page_icon="📚", layout="wide")

st.title("📚 Upload Course Materials")
st.caption("Upload textbooks, research papers, and notes. We'll build an index to power study guides, quizzes, and tutoring.")

with st.container(border=True):
    uploaded = st.file_uploader(
        "Upload PDF, DOCX, or TXT files",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
    )
    col1, col2, col3 = st.columns([1,1,1])
    with col1:
        process = st.button("Build Index", use_container_width=True)
    with col2:
        clear = st.button("Clear Workspace", use_container_width=True, type="secondary")
    with col3:
        load_samples = st.button("Load Sample Dataset", use_container_width=True)

if clear:
    st.session_state.pop("chunks", None)
    st.session_state.pop("index", None)
    st.success("Workspace cleared.")

if process:
    if not uploaded:
        st.warning("Please upload at least one file.")
    else:
        # Build structured inputs with content and filenames
        file_items = []
        for f in uploaded:
            name = getattr(f, "name", "upload")
            data = f.getvalue()
            file_items.append({"content": data, "name": name})
        chunks = parse_documents(file_items)
        index = build_index(chunks)
        st.session_state["chunks"] = chunks
        st.session_state["index"] = index
        st.success(f"Indexed {len(chunks)} content chunk(s) from {len(uploaded)} file(s).")

if 'load_samples' in locals() and load_samples:
    sample_dir = Path("samples")
    sample_paths = sorted(list(sample_dir.glob("*.txt")) + list(sample_dir.glob("*.pdf")))
    if not sample_paths:
        st.warning("No sample files found in the 'samples/' directory.")
    else:
        items = []
        for p in sample_paths:
            if p.suffix.lower() == ".txt":
                items.append({"content": p.read_text(encoding="utf-8"), "name": p.name})
            else:
                items.append({"content": p.read_bytes(), "name": p.name})
        chunks = parse_documents(items)
        index = build_index(chunks)
        st.session_state["chunks"] = chunks
        st.session_state["index"] = index
        st.success(f"Loaded and indexed {len(chunks)} chunk(s) from {len(sample_paths)} sample file(s).")

# Status panel
with st.expander("Workspace Status", expanded=True):
    chunks = st.session_state.get("chunks", [])
    index = st.session_state.get("index")
    st.write({
        "chunks": len(chunks),
        "indexed": bool(index),
    })
    if chunks:
        st.caption("Preview of first chunk:")
        st.code(chunks[0]["text"], language="markdown")

footer()
