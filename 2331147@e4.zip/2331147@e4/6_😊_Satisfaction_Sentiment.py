import streamlit as st
from src.nlp import score_sentences
import pandas as pd

st.title("😊 Satisfaction & Sentiment Analysis")

sample = [
    "My order arrived two days early, amazing service!",
    "The checkout kept failing, very frustrating experience.",
    "Support was helpful but the wait was long.",
    "Package was damaged, I need a replacement.",
]

col_a, col_b = st.columns([3,1])
with col_a:
    texts = st.text_area("Enter chat/ticket messages (one per line)", value="\n".join(sample), height=150)
with col_b:
    st.caption("Tip: Start with sample data or paste your transcripts.")

if st.button("Score Sentiment") and texts:
    lines = [l.strip() for l in texts.splitlines() if l.strip()]
    scores = score_sentences(lines)

    df = pd.DataFrame([
        {
            "text": t,
            "neg": s.neg,
            "neu": s.neu,
            "pos": s.pos,
            "compound": s.compound,
        }
        for t, s in zip(lines, scores)
    ])

    avg = df[["neg", "neu", "pos", "compound"]].mean()
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Avg Positive", f"{avg['pos']*100:.1f}%")
    with col2:
        st.metric("Avg Negative", f"{avg['neg']*100:.1f}%")
    with col3:
        st.metric("Avg Compound", f"{avg['compound']:.2f}")

    st.subheader("Message Scores")
    st.dataframe(df, use_container_width=True)
