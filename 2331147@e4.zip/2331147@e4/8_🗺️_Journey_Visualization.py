import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from src.data_store import load_demo_data
from datetime import datetime, timedelta
import numpy as np

st.title("🗺️ Customer Journey Visualization")

data = load_demo_data()

steps = ["view", "product_view", "add_to_cart", "checkout", "purchase"]

# Filters
min_ts = data.events["timestamp"].min()
max_ts = data.events["timestamp"].max()
start, end = st.slider(
    "Date range",
    min_value=min_ts.to_pydatetime(),
    max_value=max_ts.to_pydatetime(),
    value=(min_ts.to_pydatetime(), max_ts.to_pydatetime()),
)

with st.expander("Filters", expanded=False):
    cols = st.columns(3)
    with cols[0]:
        regions = sorted(data.users["region"].unique().tolist())
        region_sel = st.multiselect("Region", options=regions, default=regions)
    with cols[1]:
        vip_only = st.checkbox("VIP only", value=False)
    with cols[2]:
        min_views = st.slider("Min product views (session)", 0, 10, 0)

# Sample scenarios
st.subheader("Scenario")
scenario = st.selectbox(
    "Choose a scenario",
    [
        "Real demo data",
        "Sample: Smooth Funnel",
        "Sample: High Drop at Checkout",
        "Sample: Product View Bottleneck",
    ],
    index=0,
    help="Use a sample scenario to showcase specific funnel behaviors",
)

# Apply filters
mask = (data.events["timestamp"] >= pd.Timestamp(start)) & (data.events["timestamp"] <= pd.Timestamp(end))
ev = data.events.loc[mask].copy()
users_f = data.users.copy()
if region_sel:
    users_f = users_f[users_f["region"].isin(region_sel)]
if vip_only:
    users_f = users_f[users_f["is_vip"] == 1]
sess_f = data.sessions.merge(users_f[["user_id"]], on="user_id", how="inner")
ev = ev.merge(sess_f[["session_id", "user_id"]], on=["session_id", "user_id"], how="inner")
if min_views > 0:
    vc = ev[ev["event"] == "product_view"].groupby("session_id").size().reset_index(name="views")
    keep = vc[vc["views"] >= min_views]["session_id"]
    ev = ev[ev["session_id"].isin(keep)]

def _make_sample_events(kind: str, n_sessions: int = 60) -> pd.DataFrame:
    rng = np.random.default_rng(123)
    rows = []
    start = datetime.now() - timedelta(days=2)
    for i in range(n_sessions):
        sid = f"SS{i:05d}"
        uid = f"US{i:05d}"
        t = start + timedelta(minutes=int(rng.uniform(0, 2*24*60)))
        # base probabilities
        p_view = 1.0
        p_pview = 0.75
        p_add = 0.45
        p_co = 0.35
        p_buy = 0.28
        if kind == "Sample: Smooth Funnel":
            p_pview, p_add, p_co, p_buy = 0.9, 0.7, 0.6, 0.5
        elif kind == "Sample: High Drop at Checkout":
            p_pview, p_add, p_co, p_buy = 0.85, 0.6, 0.4, 0.15
        elif kind == "Sample: Product View Bottleneck":
            p_pview, p_add, p_co, p_buy = 0.5, 0.35, 0.3, 0.2

        # Build path
        # view
        rows.append((sid, uid, t, "view", "P0001"))
        # product_view
        if rng.random() < p_pview:
            t += timedelta(minutes=1)
            rows.append((sid, uid, t, "product_view", "P0001"))
            # add_to_cart
            if rng.random() < p_add:
                t += timedelta(minutes=1)
                rows.append((sid, uid, t, "add_to_cart", "P0001"))
                # checkout
                if rng.random() < p_co:
                    t += timedelta(minutes=1)
                    rows.append((sid, uid, t, "checkout", "P0001"))
                    # purchase
                    if rng.random() < p_buy:
                        t += timedelta(minutes=1)
                        rows.append((sid, uid, t, "purchase", "P0001"))
    return pd.DataFrame(rows, columns=["session_id", "user_id", "timestamp", "event", "product_id"])

if scenario == "Real demo data":
    ev_for_viz = ev.copy()
else:
    ev_for_viz = _make_sample_events(scenario)

# KPIs
st.subheader("Funnel KPIs")
counts_all = {s: int((ev_for_viz["event"] == s).sum()) for s in steps}
cv = 0.0 if counts_all.get("view", 0) == 0 else counts_all.get("purchase", 0) / counts_all.get("view", 1)
colk1, colk2, colk3, colk4, colk5 = st.columns(5)
with colk1:
    st.metric("Views", f"{counts_all.get('view',0):,}")
with colk2:
    st.metric("Product Views", f"{counts_all.get('product_view',0):,}")
with colk3:
    st.metric("Add to Cart", f"{counts_all.get('add_to_cart',0):,}")
with colk4:
    st.metric("Checkout", f"{counts_all.get('checkout',0):,}")
with colk5:
    st.metric("Purchases", f"{counts_all.get('purchase',0):,}")
st.metric("Overall Conversion", f"{cv*100:.1f}%")

# Build transitions counts
transitions = {}
ev_sorted = ev_for_viz.sort_values(["session_id", "timestamp"])
for sid, g in ev_sorted.groupby("session_id"):
    seq = g["event"].tolist()
    for i in range(len(seq) - 1):
        a, b = seq[i], seq[i+1]
        transitions[(a, b)] = transitions.get((a, b), 0) + 1

labels = steps
index = {s: i for i, s in enumerate(labels)}
source = []
target = []
value = []
links_tbl = []
for (a, b), v in transitions.items():
    if a in index and b in index:
        source.append(index[a])
        target.append(index[b])
        value.append(v)
        links_tbl.append({"from": a, "to": b, "count": v})

palette = ["#0ea5e9", "#22c55e", "#eab308", "#f97316", "#ef4444"]
node_colors = [palette[i % len(palette)] for i in range(len(labels))]
link_colors = ["rgba(148,163,184,0.5)" for _ in value]

fig = go.Figure(data=[go.Sankey(
    node=dict(
        pad=15,
        thickness=20,
        line=dict(color="rgba(0,0,0,0.2)", width=0.5),
        label=labels,
        color=node_colors,
    ),
    link=dict(
        source=source,
        target=target,
        value=value,
        color=link_colors,
        hovertemplate="%{source.label} → %{target.label}<br />Count: %{value}<extra></extra>",
    ),
)])
fig.update_layout(margin=dict(l=10, r=10, t=10, b=10))
st.plotly_chart(fig, use_container_width=True)

st.subheader("Transitions Table")
df_links = pd.DataFrame(links_tbl).sort_values("count", ascending=False)
st.dataframe(df_links, use_container_width=True)

with st.expander("Export (CSV)"):
    st.download_button("Download transitions.csv", df_links.to_csv(index=False).encode("utf-8"), "transitions.csv", mime="text/csv")
    if scenario == "Real demo data":
        st.download_button("Download filtered_events.csv", ev.to_csv(index=False).encode("utf-8"), "filtered_events.csv", mime="text/csv")
    else:
        st.download_button("Download sample_events.csv", ev_for_viz.to_csv(index=False).encode("utf-8"), "sample_events.csv", mime="text/csv")

# Annotated drop-offs
st.subheader("Annotated Drop-offs")
counts = {s: int((ev_for_viz["event"] == s).sum()) for s in steps}
drop_rows = []
for i in range(len(steps) - 1):
    a, b = steps[i], steps[i+1]
    da = counts.get(a, 0)
    db = counts.get(b, 0)
    loss = max(0, da - db)
    pct = 0 if da == 0 else loss / da
    drop_rows.append({"from": a, "to": b, "from_count": da, "to_count": db, "lost": loss, "drop_pct": pct})
df_drop = pd.DataFrame(drop_rows)
if not df_drop.empty:
    worst = df_drop.sort_values(["drop_pct", "from_count"], ascending=[False, False]).head(3)
    st.dataframe(df_drop, use_container_width=True)
    st.markdown("### Top drop-off points")
    for _, row in worst.iterrows():
        st.markdown(f"- {row['from']} → {row['to']}: drop {row['drop_pct']*100:.1f}% (lost {row['lost']:,} out of {row['from_count']:,})")

st.subheader("Optimization Suggestions")
suggestions = []
if not df_drop.empty:
    # Heuristics for suggestions
    if (df_drop.loc[df_drop['from'] == 'product_view', 'drop_pct'] or pd.Series([0])).max() > 0.4:
        suggestions.append("Improve product detail clarity (images, specs, reviews) to boost product_view → add_to_cart.")
    if (df_drop.loc[df_drop['from'] == 'checkout', 'drop_pct'] or pd.Series([0])).max() > 0.3:
        suggestions.append("Reduce checkout friction: fewer steps, guest checkout, multiple payment methods.")
    if (df_drop.loc[df_drop['from'] == 'add_to_cart', 'drop_pct'] or pd.Series([0])).max() > 0.35:
        suggestions.append("Introduce limited-time incentives or free shipping thresholds to encourage checkout.")
if not suggestions:
    suggestions = [
        "Improve product detail clarity to boost product_view → add_to_cart.",
        "Add checkout reminders and alternative payments to reduce checkout → purchase drop-off.",
    ]
for s in suggestions:
    st.markdown(f"- {s}")
