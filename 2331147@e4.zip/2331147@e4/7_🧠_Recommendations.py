import streamlit as st
from src.data_store import load_demo_data
from src.recommender import build_covisitation, recommend_for_session, recommend_for_product
import pandas as pd

st.title("🧠 Personalized Recommendations")

data = load_demo_data()

@st.cache_resource
def _covis():
    return build_covisitation(data.events)

covis = _covis()

mode = st.radio("Recommend by", ["Session", "Product"], horizontal=True)
top_n = st.slider("Top N", 3, 20, 10)

if mode == "Session":
    example_sid = data.sessions.session_id.iloc[0]
    sid = st.text_input("Session ID", value=example_sid)
    if st.button("Recommend") and sid:
        recs = recommend_for_session(sid, data.events, covis)[:top_n]
        df = pd.DataFrame(recs, columns=["product_id", "score"]).merge(
            data.products, on="product_id", how="left"
        )[["product_id", "name", "category", "price", "rating", "score"]]
        st.dataframe(df, use_container_width=True)
else:
    example_pid = data.products.product_id.iloc[0]
    pid = st.text_input("Product ID", value=example_pid)
    if st.button("Recommend") and pid:
        recs = recommend_for_product(pid, covis)[:top_n]
        df = pd.DataFrame(recs, columns=["product_id", "score"]).merge(
            data.products, on="product_id", how="left"
        )[["product_id", "name", "category", "price", "rating", "score"]]
        st.dataframe(df, use_container_width=True)

st.caption("Baseline co-visitation recommendations shown. Improve using personalization and embeddings.")
