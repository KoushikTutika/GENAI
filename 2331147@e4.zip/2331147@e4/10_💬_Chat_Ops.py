import streamlit as st
import pandas as pd
from src.db import get_session, TicketEscalation, ChatLog

st.title("💬 Chat Ops: Escalations & Logs")

# Escalations table
st.subheader("Open Escalations")
with get_session() as dbs:
    rows = dbs.query(TicketEscalation).order_by(TicketEscalation.created_at.desc()).all()

if rows:
    df = pd.DataFrame([
        {
            "id": r.id,
            "created_at": r.created_at,
            "session_id": r.session_id,
            "user_id": r.user_id,
            "intent": r.intent,
            "status": r.status,
            "query": r.query,
            "answer": r.answer,
        }
        for r in rows
    ])
    st.dataframe(df, use_container_width=True)
else:
    st.info("No escalations yet.")

# Update status form
st.subheader("Update Escalation Status")
esc_id = st.number_input("Escalation ID", min_value=1, step=1)
new_status = st.selectbox("New Status", ["open", "assigned", "closed"])
if st.button("Update Status"):
    with get_session() as dbs:
        rec = dbs.query(TicketEscalation).filter(TicketEscalation.id == int(esc_id)).first()
        if rec:
            rec.status = new_status
            st.success(f"Escalation {esc_id} set to {new_status}")
        else:
            st.error("Escalation not found")

# Chat logs view
st.subheader("Chat Logs (latest 200)")
with get_session() as dbs:
    logs = (
        dbs.query(ChatLog).order_by(ChatLog.ts.desc()).limit(200).all()
    )

if logs:
    df_logs = pd.DataFrame([
        {
            "ts": l.ts,
            "session_id": l.session_id,
            "user_id": l.user_id,
            "role": l.role,
            "message": l.message,
        }
        for l in logs
    ])
    st.dataframe(df_logs, use_container_width=True)
else:
    st.info("No chat logs yet.")
