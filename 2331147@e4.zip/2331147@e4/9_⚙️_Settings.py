import streamlit as st
from src.settings import load_env, set_env

st.title("⚙️ Settings & Integrations")

env = load_env()

# Current values from .env (if present)
enabled_default = str(env.get("ESCALATION_ENABLED", "false")).lower() == "true"
helpdesk_default = env.get("HELP_DESK_API_TOKEN", "")
llm_default = env.get("LLM_API_KEY", env.get("OPENAI_API_KEY", ""))
helpdesk_base = env.get("HELPDESK_BASE_URL", "")

sendgrid_key = env.get("SENDGRID_API_KEY", "")
sender_email = env.get("SENDER_EMAIL", "noreply@example.com")
tw_sid = env.get("TWILIO_ACCOUNT_SID", "")
tw_token = env.get("TWILIO_AUTH_TOKEN", "")
sender_phone = env.get("SENDER_PHONE", "+15555555555")

st.subheader("Live Chat & Helpdesk")
enabled = st.checkbox("Enable live chat escalation", value=enabled_default, help="Toggle bot-to-human handoff.")
helpdesk = st.text_input("Helpdesk API Token", value=helpdesk_default, type="password")
helpdesk_base_url = st.text_input("Helpdesk Base URL (optional)", value=helpdesk_base, help="Use for real Zendesk/Freshdesk integrations")

st.subheader("LLM Provider")
llm_key = st.text_input("LLM API Key", value=llm_default, type="password")

st.subheader("Email (SendGrid-like)")
sg_key = st.text_input("SENDGRID_API_KEY", value=sendgrid_key, type="password")
sg_sender = st.text_input("SENDER_EMAIL", value=sender_email)

st.subheader("SMS (Twilio-like)")
twilio_sid = st.text_input("TWILIO_ACCOUNT_SID", value=tw_sid)
twilio_token = st.text_input("TWILIO_AUTH_TOKEN", value=tw_token, type="password")
twilio_phone = st.text_input("SENDER_PHONE", value=sender_phone)

if st.button("Save Settings"):
    updates = {
        "ESCALATION_ENABLED": "true" if enabled else "false",
        "HELP_DESK_API_TOKEN": helpdesk.strip(),
        "HELPDESK_BASE_URL": helpdesk_base_url.strip(),
        "LLM_API_KEY": llm_key.strip(),
        "SENDGRID_API_KEY": sg_key.strip(),
        "SENDER_EMAIL": sg_sender.strip(),
        "TWILIO_ACCOUNT_SID": twilio_sid.strip(),
        "TWILIO_AUTH_TOKEN": twilio_token.strip(),
        "SENDER_PHONE": twilio_phone.strip(),
    }
    set_env(updates)
    st.success("Settings saved to .env. You may need to restart the app or container for all services to pick up changes.")

st.caption("These settings are stored in a local .env file for development. For production, use a secure secret manager.")
