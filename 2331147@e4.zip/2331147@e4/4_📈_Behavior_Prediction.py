import streamlit as st
import pandas as pd
from sklearn.linear_model import LogisticRegression

from src.data_store import load_demo_data

st.title("📈 Customer Behavior & Purchase Prediction")

data = load_demo_data()
# Simple session-level purchase label
sess = data.events.groupby("session_id").agg(
    purchased=("event", lambda x: int((x == "purchase").any())),
    add_to_cart=("event", lambda x: int((x == "add_to_cart").any())),
    views=("event", lambda x: int((x == "product_view").sum())),
).reset_index()

st.subheader("Features")
st.caption("Demo features derived per session. Extend with more behavioral signals for better accuracy.")
st.dataframe(sess.head(10))

X = sess[["add_to_cart", "views"]]
y = sess["purchased"]
if y.nunique() > 1:
    C = st.slider("Regularization strength (C)", 0.01, 10.0, 1.0, 0.01)
    clf = LogisticRegression(max_iter=1000, C=C).fit(X, y)
    proba = clf.predict_proba(X)[:, 1]

    col_a, col_b = st.columns(2)
    with col_a:
        st.metric("Accuracy (proxy)", f"{float((proba.round() == y).mean())*100:.1f}%")
    with col_b:
        st.caption("Note: This is a naive proxy, not a proper ROC-AUC.")

    st.subheader("Feature Importances (coefficients)")
    coefs = pd.DataFrame({
        "feature": ["add_to_cart", "views"],
        "coef": clf.coef_[0]
    }).sort_values("coef", ascending=False)
    st.bar_chart(coefs.set_index("feature"))

    st.subheader("Top sessions by predicted purchase probability")
    top_n = st.slider("Show top N", 10, 200, 50, 10)
    out = pd.DataFrame({
        "session_id": sess["session_id"],
        "purchase_prob": proba,
        "add_to_cart": X["add_to_cart"],
        "views": X["views"],
    }).sort_values("purchase_prob", ascending=False).head(top_n)
    st.dataframe(out, use_container_width=True)
else:
    st.warning("Not enough class diversity in demo data for training.")
