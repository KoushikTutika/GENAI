import streamlit as st
import pandas as pd
import plotly.express as px

from src.data_store import load_demo_data
from src.abandonment import compute_funnel, compute_abandonment

st.title("🏠 Dashboard")

data = load_demo_data()

# Date range filter
min_ts = data.events["timestamp"].min()
max_ts = data.events["timestamp"].max()
start, end = st.slider(
    "Date range",
    min_value=min_ts.to_pydatetime(),
    max_value=max_ts.to_pydatetime(),
    value=(min_ts.to_pydatetime(), max_ts.to_pydatetime()),
)
mask = (data.events["timestamp"] >= pd.Timestamp(start)) & (data.events["timestamp"] <= pd.Timestamp(end))
ev = data.events.loc[mask].copy()

# Segment filters
with st.expander("Filters", expanded=False):
    cols_f = st.columns(3)
    with cols_f[0]:
        regions = sorted(data.users["region"].unique().tolist())
        region_sel = st.multiselect("Region", options=regions, default=regions)
    with cols_f[1]:
        vip_only = st.checkbox("VIP only", value=False)
    with cols_f[2]:
        min_views = st.slider("Min product views (session)", 0, 10, 0)

# Apply segment filters using users/sessions
users_f = data.users.copy()
if region_sel:
    users_f = users_f[users_f["region"].isin(region_sel)]
if vip_only:
    users_f = users_f[users_f["is_vip"] == 1]

sess_f = data.sessions.merge(users_f[["user_id"]], on="user_id", how="inner")
ev = ev.merge(sess_f[["session_id", "user_id"]], on=["session_id", "user_id"], how="inner")

if min_views > 0:
    view_counts = ev[ev["event"] == "product_view"].groupby("session_id").size().reset_index(name="views")
    sess_keep = view_counts[view_counts["views"] >= min_views]["session_id"]
    ev = ev[ev["session_id"].isin(sess_keep)]

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("Monthly Users", f"{len(data.sessions['user_id'].unique()):,}")
with col2:
    st.metric("Cart Abandonment", f"{compute_abandonment(ev)*100:.1f}%")
with col3:
    st.metric("Tickets / Day", f"{int(len(data.tickets)/30):,}")
with col4:
    st.metric("Avg Order Value", f"${data.products['price'].mean():.2f}")

st.subheader("Funnel Overview")
funnel = compute_funnel(ev)
df_funnel = pd.DataFrame({"step": list(funnel.keys()), "count": list(funnel.values())})
fig = px.funnel(df_funnel, x="count", y="step")
st.plotly_chart(fig, use_container_width=True)

st.subheader("Trends")
daily = ev.copy()
daily["date"] = daily["timestamp"].dt.date
daily_counts = daily.groupby(["date", "event"]).size().reset_index(name="count")
fig2 = px.line(daily_counts, x="date", y="count", color="event", markers=True)
st.plotly_chart(fig2, use_container_width=True)

# Export CSVs
with st.expander("Export data (CSV)"):
    colx1, colx2, colx3 = st.columns(3)
    with colx1:
        csv_funnel = df_funnel.to_csv(index=False).encode("utf-8")
        st.download_button("Download funnel.csv", csv_funnel, "funnel.csv", mime="text/csv")
    with colx2:
        csv_trends = daily_counts.to_csv(index=False).encode("utf-8")
        st.download_button("Download trends.csv", csv_trends, "trends.csv", mime="text/csv")
    with colx3:
        csv_events = ev.to_csv(index=False).encode("utf-8")
        st.download_button("Download events.csv", csv_events, "events.csv", mime="text/csv")

# Conversion delta (view->purchase)
conv_daily = daily.pivot_table(index="date", columns="event", values="session_id", aggfunc="count").fillna(0)
if {"view", "purchase"}.issubset(conv_daily.columns):
    conv_daily["conv_rate"] = (conv_daily["purchase"] / conv_daily["view"]).replace([float("inf"), pd.NA], 0)
    if len(conv_daily) >= 2:
        latest = conv_daily["conv_rate"].iloc[-1]
        prev = conv_daily["conv_rate"].iloc[-2]
        delta = (latest - prev) * 100
        st.metric("Conversion Rate (daily)", f"{latest*100:.1f}%", delta=f"{delta:+.1f} pp")

st.subheader("Top Products & Categories")
# Views and purchases joined with product meta
evp = ev.merge(data.products[["product_id", "name", "category", "price"]], on="product_id", how="left")
top_viewed = evp[evp["event"] == "product_view"].groupby(["product_id", "name", "category"]).size().reset_index(name="views").sort_values("views", ascending=False).head(10)
top_purchased = evp[evp["event"] == "purchase"].groupby(["product_id", "name", "category"]).size().reset_index(name="purchases").sort_values("purchases", ascending=False).head(10)
col_tv, col_tp = st.columns(2)
with col_tv:
    st.caption("Most viewed products")
    st.dataframe(top_viewed, use_container_width=True)
with col_tp:
    st.caption("Top purchased products")
    st.dataframe(top_purchased, use_container_width=True)

col_dl1, col_dl2 = st.columns(2)
with col_dl1:
    st.download_button("Download top_viewed.csv", top_viewed.to_csv(index=False).encode("utf-8"), "top_viewed.csv", mime="text/csv")
with col_dl2:
    st.download_button("Download top_purchased.csv", top_purchased.to_csv(index=False).encode("utf-8"), "top_purchased.csv", mime="text/csv")

st.subheader("Category Conversion & Opportunities")
cat_views = evp[evp["event"] == "product_view"].groupby("category").size().reset_index(name="views")
cat_purch = evp[evp["event"] == "purchase"].groupby("category").size().reset_index(name="purchases")
cat_conv = cat_views.merge(cat_purch, on="category", how="left").fillna({"purchases": 0})
cat_conv["conv_rate"] = cat_conv.apply(lambda r: 0 if r["views"] == 0 else r["purchases"] / r["views"], axis=1)
cat_conv = cat_conv.sort_values(["conv_rate", "views"], ascending=[False, False])

col_cc1, col_cc2 = st.columns([2,1])
with col_cc1:
    st.dataframe(cat_conv, use_container_width=True)
with col_cc2:
    fig_cat = px.bar(cat_conv, x="category", y="conv_rate", title="Conversion by Category")
    fig_cat.update_layout(yaxis_tickformat=",.0%")
    st.plotly_chart(fig_cat, use_container_width=True)

# Opportunity: high views but low conversion
opp = cat_conv.copy()
if not opp.empty:
    q_views = opp["views"].quantile(0.6)
    q_conv = opp["conv_rate"].quantile(0.4)
    opp = opp[(opp["views"] >= q_views) & (opp["conv_rate"] <= q_conv)].sort_values(["conv_rate", "views"], ascending=[True, False]).head(5)
    st.caption("Top opportunities: high volume categories with relatively low conversion")
    st.dataframe(opp, use_container_width=True)

st.subheader("VIP vs Non‑VIP Comparison")
# Build per-segment KPIs based on current date/region filters
def _segment_events(vip: bool) -> pd.DataFrame:
    users_seg = data.users.copy()
    if region_sel:
        users_seg = users_seg[users_seg["region"].isin(region_sel)]
    users_seg = users_seg[users_seg["is_vip"] == (1 if vip else 0)]
    sess_seg = data.sessions.merge(users_seg[["user_id"]], on="user_id", how="inner")
    ev_seg = data.events.merge(sess_seg[["session_id", "user_id"]], on=["session_id", "user_id"], how="inner")
    # apply date range
    ev_seg = ev_seg[(ev_seg["timestamp"] >= pd.Timestamp(start)) & (ev_seg["timestamp"] <= pd.Timestamp(end))]
    return ev_seg

ev_vip = _segment_events(True)
ev_non = _segment_events(False)

def _conv_rate(df: pd.DataFrame) -> float:
    views = int((df["event"] == "view").sum())
    purchases = int((df["event"] == "purchase").sum())
    return 0.0 if views == 0 else purchases / views

col_cmp1, col_cmp2 = st.columns(2)
with col_cmp1:
    st.metric("VIP Conversion", f"{_conv_rate(ev_vip)*100:.1f}%")
with col_cmp2:
    st.metric("Non‑VIP Conversion", f"{_conv_rate(ev_non)*100:.1f}%")

st.subheader("Drop-offs")
# Compute drop-offs between sequential steps
steps = ["view", "product_view", "add_to_cart", "checkout", "purchase"]
counts = {s: int((ev["event"] == s).sum()) for s in steps}
drop = []
for i in range(len(steps) - 1):
    a, b = steps[i], steps[i+1]
    da = counts.get(a, 0)
    db = counts.get(b, 0)
    if da > 0:
        drop.append({"from": a, "to": b, "drop_pct": float(max(0, da - db) / da)})
df_drop = pd.DataFrame(drop)
if not df_drop.empty:
    fig3 = px.bar(df_drop, x="from", y="drop_pct", text="to", title="Drop-off by step", labels={"drop_pct": "Drop %"})
    fig3.update_layout(yaxis_tickformat=",.0%")
    st.plotly_chart(fig3, use_container_width=True)

st.subheader("Quick Links")
try:
    st.page_link("pages/3_🛒_Cart_Abandonment.py", label="🛒 Cart Abandonment", icon="🛒")
    st.page_link("pages/5_🎫_Ticket_Routing.py", label="🎫 Ticket Routing", icon="🎫")
    st.page_link("pages/2_🤖_AI_Chatbot.py", label="🤖 AI Chatbot", icon="🤖")
except Exception:
    st.markdown("- Go to 🛒 Cart Abandonment to launch recovery campaigns\n- Go to 🎫 Ticket Routing to categorize and push tickets\n- Go to 🤖 AI Chatbot to upload knowledge and answer FAQs")
