import streamlit as st
import pandas as pd
import plotly.express as px
from src.data_store import load_demo_data
from src.abandonment import compute_abandonment, trigger_interventions
from src.providers import EmailProvider, SMSProvider

st.title("🛒 Cart Abandonment & Interventions")

data = load_demo_data()
rate = compute_abandonment(data.events)
col_a, col_b, col_c = st.columns(3)
with col_a:
    st.metric("Cart Abandonment Rate", f"{rate*100:.1f}%")
with col_b:
    added = int((data.events.event == "add_to_cart").sum())
    st.metric("Adds to Cart", f"{added:,}")
with col_c:
    purchased = int((data.events.event == "purchase").sum())
    st.metric("Purchases", f"{purchased:,}")

st.subheader("Intervention Candidates")
threshold = st.slider("Minimum minutes since checkout to trigger recovery", 0, 180, 30, 5,
                      help="Customers who checked out but did not purchase within this time are candidates.")
pend = trigger_interventions(data.events)
if not pend.empty:
    # If dataset supports time deltas, filter here (demo shows static action)
    df_show = pend.head(50).copy()
    df_show.index = range(1, len(df_show) + 1)
    st.dataframe(df_show, use_container_width=True)

    cols = st.columns(2)
    with cols[0]:
        incentive = st.selectbox("Incentive", ["5% off", "10% off", "Free shipping", "Loyalty points"], index=1)
    with cols[1]:
        channel = st.selectbox("Channel", ["Email", "SMS"], index=0)

    if st.button("Send Recovery"):
        # Build faux contact info from user_id for demo purposes
        sample = df_show.head(50)
        emails = [f"{uid.lower()}@example.com" for uid in sample["user_id"].astype(str).tolist()]
        phones = ["+1555" + str(i).zfill(7) for i in range(len(sample))]

        subject = f"We saved your cart — {incentive}!"
        body = "We noticed you left items in your cart. Complete your purchase and enjoy " + incentive + "."

        if channel == "Email":
            provider = EmailProvider()
            res = provider.send_bulk(emails, subject, body)
        else:
            provider = SMSProvider()
            res = provider.send_bulk(phones, body)

        if res.get("ok"):
            if res.get("dry_run"):
                st.info("Dry-Run: No provider credentials found in .env. Messages not actually sent.")
            st.success("Recovery campaign queued.")
            with st.expander("Provider response/payload"):
                st.json(res)
        else:
            st.error("Failed to send recovery campaign.")
            with st.expander("Error details"):
                st.json(res)
else:
    st.info("No current candidates detected.")

st.caption("Trigger example: Send recovery email with incentive after checkout w/o purchase.")
