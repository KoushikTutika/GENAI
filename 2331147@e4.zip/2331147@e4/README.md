# Customer Service & Conversion Optimization App (Streamlit)

An AI-powered Streamlit application for an online retailer with 50k monthly customers to reduce cart abandonment, speed up support resolution, and boost conversions.

## Key Features (MVP)
- AI chatbot for instant customer query resolution (RAG over FAQs/policies)
- Cart abandonment analysis with intervention triggers
- Customer behavior tracking and purchase prediction (baseline model)
- Automated support ticket categorization and routing
- Real-time satisfaction scoring and sentiment analysis (VADER)
- Personalized product recommendations (co-visitation/session-based)
- Live chat escalation system (bot-to-human handoff stub)
- Customer journey visualization and optimization suggestions (Sankey)

## Tech Stack
- Python, Streamlit
- Pandas, scikit-learn, Plotly/Altair
- FAISS + Sentence-Transformers (RAG embeddings)
- NLTK VADER sentiment
- BeautifulSoup + Requests for scraping
- SQLAlchemy (SQLite for local dev)

## Quickstart
1) (Recommended) Use a virtual environment
```
python3 -m venv .venv
source .venv/bin/activate
```
2) Install dependencies
```
pip install -r requirements.txt
python -m nltk.downloader vader_lexicon
```
3) Run the app
```
streamlit run app.py
```

## Data Notes
- Demo uses synthetic data in `src/data_store.py` to simulate users, sessions, events, carts, orders, and tickets.
- Replace with real data sources or connect ingestion endpoints.

## Environment
- Copy `.env.example` to `.env` and set your keys.
- You can also configure these in the app via `Pages -> ⚙️ Settings & Integrations`, which writes to `.env`.

Supported variables:

```
# Preferred LLM API key (used by chatbot and other AI features)
LLM_API_KEY=

# Backwards-compat key name
OPENAI_API_KEY=

# Toggle bot-to-human handoff (live chat escalation)
ESCALATION_ENABLED=false

# Helpdesk provider token (e.g., Zendesk/Freshdesk)
HELP_DESK_API_TOKEN=

# Optional: Provider-specific token (example)
ZENDESK_API_TOKEN=
```

## Compliance & Safety
- Respect robots.txt and site ToS when running scraping.
- Configure PII handling, consent, and retention for production.
