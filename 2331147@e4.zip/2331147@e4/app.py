import streamlit as st
from pathlib import Path
from src.db import init_db

st.set_page_config(page_title="CX & Conversion Ops", page_icon="🛍️", layout="wide", initial_sidebar_state="expanded")

st.sidebar.title("Navigation")
try:
    st.sidebar.page_link("app.py", label="🏠 Home")
    st.sidebar.page_link("pages/1_🏠_Dashboard.py", label="🏠 Dashboard")
    st.sidebar.page_link("pages/2_🤖_AI_Chatbot.py", label="🤖 AI Chatbot")
    st.sidebar.page_link("pages/3_🛒_Cart_Abandonment.py", label="🛒 Cart Abandonment")
    st.sidebar.page_link("pages/4_📈_Behavior_Prediction.py", label="📈 Behavior Prediction")
    st.sidebar.page_link("pages/5_🎫_Ticket_Routing.py", label="🎫 Ticket Routing")
    st.sidebar.page_link("pages/6_😊_Satisfaction_Sentiment.py", label="😊 Sentiment Analysis")
    st.sidebar.page_link("pages/7_🧠_Recommendations.py", label="🧠 Recommendations")
    st.sidebar.page_link("pages/8_🗺️_Journey_Visualization.py", label="🗺️ Journey Visualization")
    st.sidebar.page_link("pages/9_⚙️_Settings.py", label="⚙️ Settings")
    st.sidebar.page_link("pages/10_💬_Chat_Ops.py", label="💬 Chat Ops")
except Exception:
    st.sidebar.markdown("Use the Pages section to navigate.")

st.title("Customer Experience & Conversion Operations Platform")
st.markdown(
    """
This application helps reduce cart abandonment, accelerate support response, and increase revenue.

Use the sidebar Pages to explore:
- AI Chatbot
- Cart Abandonment Analytics & Triggers
- Customer Behavior & Purchase Prediction
- Ticket Categorization & Routing
- Satisfaction & Sentiment Analytics
- Personalized Recommendations
- Live Chat Escalation
- Customer Journey Visualization & Suggestions
    """
)

st.info("Tip: Synthetic demo data is auto-generated. Connect to your real data in `src/data_store.py`.")

if Path(".env").exists():
    st.caption("Loaded .env for secrets.")
else:
    st.caption("No .env found. Create one from .env.example if integrating external APIs.")

# Initialize local SQLite DB for chat logs and escalations
try:
    init_db()
    st.caption("SQLite DB initialized at ./app.db")
except Exception as e:
    st.warning(f"DB init failed: {e}")
