import streamlit as st
from src.ticket_classifier import TicketRouter
from src.settings import load_env
from src.helpdesk import HelpdeskClient

st.title("🎫 Ticket Categorization & Routing")

@st.cache_resource
def _router():
    return TicketRouter()

router = _router()

st.subheader("Compose or use a sample ticket")

cols = st.columns(3)
with cols[0]:
    sample_cat = st.selectbox("Sample Category", [
        "Shipping", "Payment", "Returns", "Product Issue", "Account", "Other"
    ], index=0)
with cols[1]:
    priority = st.selectbox("Priority", ["Low", "Medium", "High", "Urgent"], index=1)
with cols[2]:
    use_sample = st.checkbox("Prefill sample text", value=True)

def _sample_message(category: str) -> str:
    samples = {
        "Shipping": "My package is delayed beyond the estimated delivery date. Can you check the status?",
        "Payment": "My card was charged twice for the same order. I need a refund.",
        "Returns": "I'd like to return an item that arrived damaged. What is the process?",
        "Product Issue": "The headphones I received are not turning on even after charging.",
        "Account": "I'm unable to reset my password and can't access my account.",
        "Other": "I have a question about gift wrapping options at checkout.",
    }
    return samples.get(category, "")

default_text = _sample_message(sample_cat) if use_sample else ""
text = st.text_area("Ticket message", value=default_text, height=150)

st.subheader("Routing")
queue = st.selectbox("Assign to queue", [
    "General Support", "Billing", "Returns", "Technical", "Accounts"
], index=0)
sla_hint = {
    "Low": "Response in 24-48h",
    "Medium": "Response in 8-24h",
    "High": "Response in 4-8h",
    "Urgent": "Response in 1-4h",
}.get(priority, "Response in 24-48h")
st.caption(f"SLA Hint: {sla_hint}")

env = load_env()
client = HelpdeskClient(api_token=env.get("HELP_DESK_API_TOKEN"))

cols2 = st.columns(2)
with cols2[0]:
    do_categorize = st.button("Categorize")
with cols2[1]:
    do_send = st.button("Send to Helpdesk")

if (do_categorize or do_send) and text.strip():
    cat = router.predict([text])[0]
    st.markdown(f"Predicted Category: <span style='background:#eef2ff;color:#3730a3;padding:2px 8px;border-radius:12px'>{cat}</span>", unsafe_allow_html=True)
    st.caption("Routing rules can assign to the right queue with SLA.")

    if do_send:
        subject = f"[{priority}] {cat} ticket"
        desc = text + f"\n\nQueue: {queue}"
        res = client.create_ticket(subject=subject, description=desc, category=cat, priority=priority)
        if res.get("ok"):
            if res.get("dry_run"):
                st.info("Dry-run: No API token configured. Ticket not actually sent.")
            st.success("Ticket queued successfully.")
            with st.expander("Helpdesk response/payload"):
                st.json(res)
        else:
            st.error("Failed to create ticket.")
            with st.expander("Error details"):
                st.json(res)
