# Restaurant Menu Optimization (Streamlit)

A Python + Streamlit app to optimize restaurant menus across locations.

Features (MVP)
- Real-time dashboard: menu performance, profit margins, popularity scores.
- AI-like recommendations: menu changes and pricing adjustments (rule-based to start).
- Customer review sentiment analysis (VADER) integration.
- Seasonal demand forecasting (simple time-series baseline).
- Competitor price monitoring (sample data + HTTP fetch stub).
- Kitchen waste optimization suggestions.
- Mobile-responsive UI (Streamlit, multipage).
- POS integration: upload CSVs for sales, costs, waste, reviews, competitors.

Quickstart
1. Create a virtualenv and install deps:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Run the app:
   ```bash
   streamlit run app.py
   ```
3. Use the `Settings` page to switch between sample data and your uploads.

Data Model (CSV)
- data/sales.csv: timestamp, location_id, item_id, item_name, qty, price
- data/costs.csv: item_id, ingredient_cost
- data/waste.csv: timestamp, location_id, item_id, qty_wasted, reason
- data/reviews.csv: timestamp, location_id, item_id, review_text, rating
- data/competitors.csv: competitor, item_name, price, url

Notes
- Sentiment uses NLTK VADER. The app will download the lexicon on first run if missing.
- Forecasting uses a simple model suitable for a small MVP dataset.
- Replace sample data with your own via the POS Integration page.
