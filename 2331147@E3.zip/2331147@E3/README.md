# Hospital Research Assistant (Streamlit)

An MVP Streamlit app to help a hospital research department ingest literature, summarize case-specific evidence, compare protocols, set alerts, generate recommendations with citations, collaborate with annotations, check compliance, and monitor new research.

## Features (MVP)
- Upload PDFs and extract key insights and keywords
- Case-specific research summaries with citations from uploaded papers
- Compare treatment protocols (basic heuristic ratings)
- Alerts for new research via PubMed keywords
- Evidence-based recommendation templates with citations
- Collaborative annotations per document
- Compliance checking against guideline keywords
- Manual literature monitoring and synthesis

## Tech Stack
- Python, Streamlit
- SQLite for local persistence (no external DB required)
- Simple TF-IDF for semantic retrieval (scikit-learn)
- PubMed E-utilities via `requests`

## Setup
1. Create and activate a virtual environment (recommended)
2. Install dependencies
3. Run the app

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
streamlit run app.py
```

## Optional: API Keys
This MVP uses PubMed E-utilities which do not require an API key, but you can set an email to comply with NCBI policies via `.env`:

```
NCBI_EMAIL=your_email@example.com
```

## Data Storage
- SQLite file at `data/app.db`
- Uploaded files saved in `data/uploads/`

## Disclaimer
This tool is for clinician support and research workflow acceleration only. It does not provide medical advice. Review all AI-generated content and citations before making clinical decisions.
